WHAT TO SUBMIT
1. Your published website URL
2. The project folder or zip file if your instructor asks for source files
3. PROJECT_WRITEUP.txt for the topic approval / planning sheet / presentation notes

HOW TO OPEN LOCALLY
Open index.html in Chrome, Edge, or Firefox.

HOW TO PUBLISH WITH GITHUB PAGES
1. Go to github.com and create/sign in to your account.
2. Click New Repository.
3. Name it explore-world-travel.
4. Upload every file and folder from this project.
5. Go to Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Choose main branch and root folder.
8. Save.
9. Your live URL will look like:
   https://yourusername.github.io/explore-world-travel/

HOW TO PUBLISH WITH NETLIFY
1. Go to netlify.com.
2. Log in or create an account.
3. Choose Add new site > Deploy manually.
4. Drag the entire explore-world-travel folder into Netlify.
5. Netlify will give you a live website link.

FORM NOTE
The contact form uses FormSubmit. The first time someone submits it, FormSubmit may send a confirmation email to oosalih98@gmail.com.
